# X Action Queue V3.2

Changes from V2:
- Like and Repost ask for Intent vs Normal every time a new session is entered.
- The opening-method choice is temporary for the current batch and is never persisted.
- Normal mode opens the regular X post URL.
- Intent mode uses X's like/repost intent route.
- Queue index is advanced and rendered before launching Chrome, removing the return-time JavaScript/onResume handoff.
- Android WebView uses hardware acceleration and default caching.
- Reply also prepares the next queue state before launching Chrome.

Build with AndroidForge.
