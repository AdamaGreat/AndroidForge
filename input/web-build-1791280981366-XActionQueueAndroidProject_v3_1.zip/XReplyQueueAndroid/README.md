# X Action Queue V2

Three separate workflows:
- Reply: Grok-generated replies, then one-by-one Chrome queue.
- Repost: normal X post URL, manual repost, automatic advance on return.
- Like: normal X post URL, manual like, automatic advance on return.

The app never logs into X and never performs the X action automatically.


V3 changes: Like/Repost choose Intent or Normal opening per batch; last choice is remembered. WebView stays resident and uses hardware acceleration/caching for quicker return from Chrome.
