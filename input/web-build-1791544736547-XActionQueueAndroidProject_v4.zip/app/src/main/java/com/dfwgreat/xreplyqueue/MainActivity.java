package com.dfwgreat.xreplyqueue;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;

    // Set (on the bridge thread) when a launch of Chrome succeeded; cleared when the return is delivered.
    private volatile boolean waitingForXReturn = false;
    // Set in onPause only after a successful launch, i.e. Chrome really took over the screen.
    // onResume reports a return to the page only when both flags are set, and clears both first,
    // so one launch produces at most one onReturnedFromX call.
    private volatile boolean leftForX = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        // Keep the page's renderer at foreground priority while Chrome is on screen, so the
        // return handler is not queued behind a de-prioritised (or killed) renderer.
        if (Build.VERSION.SDK_INT >= 26) {
            web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        }
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NativeBridge(), "Android");
        web.loadUrl("file:///android_asset/x_reply_queue.html");
        setContentView(web);
    }

    @Override protected void onPause() {
        super.onPause();
        if (waitingForXReturn) leftForX = true;
    }

    @Override protected void onResume() {
        super.onResume();
        if (waitingForXReturn && leftForX && web != null) {
            waitingForXReturn = false;
            leftForX = false;
            web.evaluateJavascript("window.onReturnedFromX && window.onReturnedFromX()", null);
        }
    }

    private void toast(final String message) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean openInChrome(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.setPackage("com.android.chrome");
            leftForX = false;
            waitingForXReturn = true;
            startActivity(i);
            return true;
        } catch (Exception e) {
            waitingForXReturn = false;
            leftForX = false;
            toast("Chrome could not be opened");
            return false;
        }
    }

    public class NativeBridge {
        @JavascriptInterface public boolean openReplyInChrome(String url) {
            return openInChrome(url);
        }

        @JavascriptInterface public boolean openPostInChrome(String url) {
            return openInChrome(url);
        }

        @JavascriptInterface public String getAppVersion() {
            try {
                PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0);
                long code = Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
                return p.versionName + " (code " + code + ")";
            } catch (Exception e) {
                return "unknown";
            }
        }

        @JavascriptInterface public void openGrokApp() {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage("ai.x.grok");
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } else {
                    toast("Grok app not found");
                }
            } catch (Exception e) {
                toast("Grok could not be opened");
            }
        }
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
