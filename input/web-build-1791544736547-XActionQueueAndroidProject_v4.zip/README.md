# X Action Queue 1.2-chooser-return (versionCode 10)

Built on the V2 project. V2's interface and Reply workflow are preserved.

Changes from V2:
- Like and Repost ask "Use Intent" or "Open Normally" every time you enter the action (and on every new batch / app restart).
  The choice is held in memory only and is never saved.
- Reply/Like/Repost return handling still runs through MainActivity.onResume -> window.onReturnedFromX, but is now
  exactly-once: the page records the single launch it made and advances only from that post, and only after Chrome
  actually took over the screen (onPause) and the app came back (onResume). A failed Chrome launch never advances.
- WebView renderer is kept at foreground priority while Chrome is open (API 26+), to cut return latency.
- Home screen shows a build label: "Build 1.2-chooser-return · app <versionName> (code <versionCode>)".
  The app part is read from the installed APK, so it shows what is actually installed.
- Toasts are shown on the UI thread (V2 raised them from the bridge thread).

Project root = this folder (settings.gradle is at the top level). Build with AndroidForge.
