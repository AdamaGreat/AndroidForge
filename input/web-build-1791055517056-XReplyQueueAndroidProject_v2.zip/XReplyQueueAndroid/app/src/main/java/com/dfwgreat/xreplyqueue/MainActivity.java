package com.dfwgreat.xreplyqueue;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    private boolean waitingForXReturn = false;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NativeBridge(), "Android");
        web.loadUrl("file:///android_asset/x_reply_queue.html");
        setContentView(web);
    }
    @Override protected void onResume() {
        super.onResume();
        if (waitingForXReturn && web != null) {
            waitingForXReturn = false;
            web.evaluateJavascript("window.onReturnedFromX && window.onReturnedFromX()", null);
        }
    }

    public class NativeBridge {
        @JavascriptInterface public void openReplyInChrome(String url) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.setPackage("com.android.chrome");
                waitingForXReturn = true;
                startActivity(i);
            } catch (Exception e) {
                waitingForXReturn = false;
                Toast.makeText(MainActivity.this, "Chrome could not be opened", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface public void openGrokApp() {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage("ai.x.grok");
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } else {
                    Toast.makeText(MainActivity.this, "Grok app not found", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Grok could not be opened", Toast.LENGTH_SHORT).show();
            }
        }
    }
    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
