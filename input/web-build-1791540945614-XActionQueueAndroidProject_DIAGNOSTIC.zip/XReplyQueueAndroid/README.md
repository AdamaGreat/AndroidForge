X Action Queue V3.7

Build the Android Gradle project in this folder: XReplyQueueAndroid. The WebView loads app/src/main/assets/x_reply_queue.html. The Like and Repost pages each have a dedicated Intent / Normal chooser shown on every new session; no preference is saved.


Diagnostic build ID: DIAGNOSTIC BUILD • CHOOSER TEST • 2026-10-09. Confirm this exact text appears on the home screen before testing.
