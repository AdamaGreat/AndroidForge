package com.dfwgreat.xactionqueue.v35;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.view.Window;
import android.graphics.Color;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NativeBridge(), "Android");
        web.loadUrl("file:///android_asset/xaq_v35.html");
        setContentView(web);
    }

    private void openInChrome(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.setPackage("com.android.chrome");
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(MainActivity.this, "Chrome could not be opened", Toast.LENGTH_SHORT).show();
        }
    }

    public class NativeBridge {
        @JavascriptInterface public void openReplyInChrome(String url) {
            openInChrome(url);
        }

        @JavascriptInterface public void openPostInChrome(String url) {
            openInChrome(url);
        }

        @JavascriptInterface public void openGrokApp() {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage("ai.x.grok");
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } else {
                    Toast.makeText(MainActivity.this, "Grok app not found", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Grok could not be opened", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
