# X Action Queue Source Verification Build

Three separate workflows:
- Reply: Grok-generated replies, then one-by-one Chrome queue.
- Repost: normal X post URL, manual repost, automatic advance on return.
- Like: normal X post URL, manual like, automatic advance on return.

The app never logs into X and never performs the X action automatically.


## Version 1.2 changes
- Based on the V2 project structure and existing Reply workflow.
- Like and Repost now ask each time whether to use Intent or open the normal post URL. The choice resets for each new batch.
- Visible homepage build marker: BUILD 1.2 · LIKE/REPOST CHOOSER.
- Repost/Like queue advancement remains tied to returning from Chrome, as in V2.


## Source verification build
- Separate Android application ID: `com.dfwgreat.xreplyqueue.sourcecheck` so it installs alongside the existing app instead of replacing it.
- Version name: `9.9-source-check`; version code: 99.
- Home screen marker: `SOURCE CHECK 9.9 · CHOOSER TEST`.
- Includes Like/Repost opening-method chooser changes.
