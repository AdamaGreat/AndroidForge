# X Action Queue V2

Three separate workflows:
- Reply: Grok-generated replies, then one-by-one Chrome queue.
- Repost: normal X post URL, manual repost, automatic advance on return.
- Like: normal X post URL, manual like, automatic advance on return.

The app never logs into X and never performs the X action automatically.


## Version 1.2 changes
- Based on the V2 project structure and existing Reply workflow.
- Like and Repost now ask each time whether to use Intent or open the normal post URL. The choice resets for each new batch.
- Visible homepage build marker: BUILD 1.2 · LIKE/REPOST CHOOSER.
- Repost/Like queue advancement remains tied to returning from Chrome, as in V2.
